package com.sschr15.z3kt

import com.microsoft.z3.*

/**
 * A z3 context. This is the entry point for all z3 operations.
 */
@Suppress("UNCHECKED_CAST", "FunctionName", "DANGEROUS_CHARACTERS", "ERROR_SUPPRESSION")
public class Z3Context @PublishedApi internal constructor() : Context() {
    //region: Comparisons
    public infix fun <T : Sort> Expr<T>.eq(other: Expr<T>): BoolExpr = mkEq(this, other)
    public infix fun <T : Sort> Expr<T>.neq(other: Expr<T>): BoolExpr = mkNot(mkEq(this, other))
    public infix fun <T : ArithSort> Expr<T>.lt(other: Expr<T>): BoolExpr = mkLt(this, other)
    public infix fun <T : ArithSort> Expr<T>.gt(other: Expr<T>): BoolExpr = mkGt(this, other)
    public infix fun <T : ArithSort> Expr<T>.lte(other: Expr<T>): BoolExpr = mkLe(this, other)
    public infix fun <T : ArithSort> Expr<T>.gte(other: Expr<T>): BoolExpr = mkGe(this, other)

    public infix fun <T : ArithSort> Expr<T>.eq(other: Int): BoolExpr = mkEq(this, mkInt(other))
    public infix fun <T : ArithSort> Expr<T>.neq(other: Int): BoolExpr = mkNot(mkEq(this, mkInt(other)))
    public infix fun <T : ArithSort> Expr<T>.lt(other: Int): BoolExpr = mkLt(this, mkInt(other))
    public infix fun <T : ArithSort> Expr<T>.gt(other: Int): BoolExpr = mkGt(this, mkInt(other))
    public infix fun <T : ArithSort> Expr<T>.lte(other: Int): BoolExpr = mkLe(this, mkInt(other))
    public infix fun <T : ArithSort> Expr<T>.gte(other: Int): BoolExpr = mkGe(this, mkInt(other))

    public infix fun <T : ArithSort> Expr<T>.eq(other: Long): BoolExpr = mkEq(this, mkInt(other))
    public infix fun <T : ArithSort> Expr<T>.neq(other: Long): BoolExpr = mkNot(mkEq(this, mkInt(other)))
    public infix fun <T : ArithSort> Expr<T>.lt(other: Long): BoolExpr = mkLt(this, mkInt(other))
    public infix fun <T : ArithSort> Expr<T>.gt(other: Long): BoolExpr = mkGt(this, mkInt(other))
    public infix fun <T : ArithSort> Expr<T>.lte(other: Long): BoolExpr = mkLe(this, mkInt(other))
    public infix fun <T : ArithSort> Expr<T>.gte(other: Long): BoolExpr = mkGe(this, mkInt(other))

    public infix fun <T : ArithSort> Int.eq(other: Expr<T>): BoolExpr = mkEq(mkInt(this), other)
    public infix fun <T : ArithSort> Int.neq(other: Expr<T>): BoolExpr = mkNot(mkEq(mkInt(this), other))
    public infix fun <T : ArithSort> Int.lt(other: Expr<T>): BoolExpr = mkLt(mkInt(this), other)
    public infix fun <T : ArithSort> Int.gt(other: Expr<T>): BoolExpr = mkGt(mkInt(this), other)
    public infix fun <T : ArithSort> Int.lte(other: Expr<T>): BoolExpr = mkLe(mkInt(this), other)
    public infix fun <T : ArithSort> Int.gte(other: Expr<T>): BoolExpr = mkGe(mkInt(this), other)

    public infix fun <T : ArithSort> Long.eq(other: Expr<T>): BoolExpr = mkEq(mkInt(this), other)
    public infix fun <T : ArithSort> Long.neq(other: Expr<T>): BoolExpr = mkNot(mkEq(mkInt(this), other))
    public infix fun <T : ArithSort> Long.lt(other: Expr<T>): BoolExpr = mkLt(mkInt(this), other)
    public infix fun <T : ArithSort> Long.gt(other: Expr<T>): BoolExpr = mkGt(mkInt(this), other)
    public infix fun <T : ArithSort> Long.lte(other: Expr<T>): BoolExpr = mkLe(mkInt(this), other)
    public infix fun <T : ArithSort> Long.gte(other: Expr<T>): BoolExpr = mkGe(mkInt(this), other)

    @JvmName("bvlt") public infix fun Expr<BitVecSort>.lt(other: Expr<BitVecSort>): BoolExpr = mkBVSLT(this, other)
    @JvmName("bvgt") public infix fun Expr<BitVecSort>.gt(other: Expr<BitVecSort>): BoolExpr = mkBVSGT(this, other)
    @JvmName("bvlte") public infix fun Expr<BitVecSort>.lte(other: Expr<BitVecSort>): BoolExpr = mkBVSLE(this, other)
    @JvmName("bvgte") public infix fun Expr<BitVecSort>.gte(other: Expr<BitVecSort>): BoolExpr = mkBVSGE(this, other)
    @JvmName("bvult") public infix fun Expr<BitVecSort>.ult(other: Expr<BitVecSort>): BoolExpr = mkBVULT(this, other)
    @JvmName("bvugt") public infix fun Expr<BitVecSort>.ugt(other: Expr<BitVecSort>): BoolExpr = mkBVUGT(this, other)
    @JvmName("bvulte") public infix fun Expr<BitVecSort>.ulte(other: Expr<BitVecSort>): BoolExpr = mkBVULE(this, other)
    @JvmName("bvugte") public infix fun Expr<BitVecSort>.ugte(other: Expr<BitVecSort>): BoolExpr = mkBVUGE(this, other)

    @JvmName("bvEq") public infix fun Expr<BitVecSort>.eq(other: Int): BoolExpr = mkEq(this, mkBV(other, sort.size))
    @JvmName("bvNeq") public infix fun Expr<BitVecSort>.neq(other: Int): BoolExpr = mkNot(mkEq(this, mkBV(other, sort.size)))
    @JvmName("bvlt") public infix fun Expr<BitVecSort>.lt(other: Int): BoolExpr = mkBVSLT(this, mkBV(other, sort.size))
    @JvmName("bvgt") public infix fun Expr<BitVecSort>.gt(other: Int): BoolExpr = mkBVSGT(this, mkBV(other, sort.size))
    @JvmName("bvlte") public infix fun Expr<BitVecSort>.lte(other: Int): BoolExpr = mkBVSLE(this, mkBV(other, sort.size))
    @JvmName("bvgte") public infix fun Expr<BitVecSort>.gte(other: Int): BoolExpr = mkBVSGE(this, mkBV(other, sort.size))
    @JvmName("bvult") public infix fun Expr<BitVecSort>.ult(other: Int): BoolExpr = mkBVULT(this, mkBV(other, sort.size))
    @JvmName("bvugt") public infix fun Expr<BitVecSort>.ugt(other: Int): BoolExpr = mkBVUGT(this, mkBV(other, sort.size))
    @JvmName("bvulte") public infix fun Expr<BitVecSort>.ulte(other: Int): BoolExpr = mkBVULE(this, mkBV(other, sort.size))
    @JvmName("bvugte") public infix fun Expr<BitVecSort>.ugte(other: Int): BoolExpr = mkBVUGE(this, mkBV(other, sort.size))

    @JvmName("bveq") public infix fun Expr<BitVecSort>.eq(other: Long): BoolExpr = mkEq(this, mkBV(other, sort.size))
    @JvmName("bvneq") public infix fun Expr<BitVecSort>.neq(other: Long): BoolExpr = mkNot(mkEq(this, mkBV(other, sort.size)))
    @JvmName("bvlt") public infix fun Expr<BitVecSort>.lt(other: Long): BoolExpr = mkBVSLT(this, mkBV(other, sort.size))
    @JvmName("bvgt") public infix fun Expr<BitVecSort>.gt(other: Long): BoolExpr = mkBVSGT(this, mkBV(other, sort.size))
    @JvmName("bvlte") public infix fun Expr<BitVecSort>.lte(other: Long): BoolExpr = mkBVSLE(this, mkBV(other, sort.size))
    @JvmName("bvgte") public infix fun Expr<BitVecSort>.gte(other: Long): BoolExpr = mkBVSGE(this, mkBV(other, sort.size))
    @JvmName("bvult") public infix fun Expr<BitVecSort>.ult(other: Long): BoolExpr = mkBVULT(this, mkBV(other, sort.size))
    @JvmName("bvugt") public infix fun Expr<BitVecSort>.ugt(other: Long): BoolExpr = mkBVUGT(this, mkBV(other, sort.size))
    @JvmName("bvulte") public infix fun Expr<BitVecSort>.ulte(other: Long): BoolExpr = mkBVULE(this, mkBV(other, sort.size))
    @JvmName("bvugte") public infix fun Expr<BitVecSort>.ugte(other: Long): BoolExpr = mkBVUGE(this, mkBV(other, sort.size))

    @JvmName("bveq") public infix fun Int.eq(other: Expr<BitVecSort>): BoolExpr = mkEq(mkBV(this, other.sort.size), other)
    @JvmName("bvneq") public infix fun Int.neq(other: Expr<BitVecSort>): BoolExpr = mkNot(mkEq(mkBV(this, other.sort.size), other))
    @JvmName("bvlt") public infix fun Int.lt(other: Expr<BitVecSort>): BoolExpr = mkBVSLT(mkBV(this, other.sort.size), other)
    @JvmName("bvgt") public infix fun Int.gt(other: Expr<BitVecSort>): BoolExpr = mkBVSGT(mkBV(this, other.sort.size), other)
    @JvmName("bvlte") public infix fun Int.lte(other: Expr<BitVecSort>): BoolExpr = mkBVSLE(mkBV(this, other.sort.size), other)
    @JvmName("bvgte") public infix fun Int.gte(other: Expr<BitVecSort>): BoolExpr = mkBVSGE(mkBV(this, other.sort.size), other)
    @JvmName("bvult") public infix fun Int.ult(other: Expr<BitVecSort>): BoolExpr = mkBVULT(mkBV(this, other.sort.size), other)
    @JvmName("bvugt") public infix fun Int.ugt(other: Expr<BitVecSort>): BoolExpr = mkBVUGT(mkBV(this, other.sort.size), other)
    @JvmName("bvulte") public infix fun Int.ulte(other: Expr<BitVecSort>): BoolExpr = mkBVULE(mkBV(this, other.sort.size), other)
    @JvmName("bvugte") public infix fun Int.ugte(other: Expr<BitVecSort>): BoolExpr = mkBVUGE(mkBV(this, other.sort.size), other)

    @JvmName("bveq") public infix fun Long.eq(other: Expr<BitVecSort>): BoolExpr = mkEq(mkBV(this, other.sort.size), other)
    @JvmName("bvneq") public infix fun Long.neq(other: Expr<BitVecSort>): BoolExpr = mkNot(mkEq(mkBV(this, other.sort.size), other))
    @JvmName("bvlt") public infix fun Long.lt(other: Expr<BitVecSort>): BoolExpr = mkBVSLT(mkBV(this, other.sort.size), other)
    @JvmName("bvgt") public infix fun Long.gt(other: Expr<BitVecSort>): BoolExpr = mkBVSGT(mkBV(this, other.sort.size), other)
    @JvmName("bvlte") public infix fun Long.lte(other: Expr<BitVecSort>): BoolExpr = mkBVSLE(mkBV(this, other.sort.size), other)
    @JvmName("bvgte") public infix fun Long.gte(other: Expr<BitVecSort>): BoolExpr = mkBVSGE(mkBV(this, other.sort.size), other)
    @JvmName("bvult") public infix fun Long.ult(other: Expr<BitVecSort>): BoolExpr = mkBVULT(mkBV(this, other.sort.size), other)
    @JvmName("bvugt") public infix fun Long.ugt(other: Expr<BitVecSort>): BoolExpr = mkBVUGT(mkBV(this, other.sort.size), other)
    @JvmName("bvulte") public infix fun Long.ulte(other: Expr<BitVecSort>): BoolExpr = mkBVULE(mkBV(this, other.sort.size), other)
    @JvmName("bvugte") public infix fun Long.ugte(other: Expr<BitVecSort>): BoolExpr = mkBVUGE(mkBV(this, other.sort.size), other)

    @JvmName("fplt") public infix fun Expr<FPSort>.lt(other: Expr<FPSort>): BoolExpr = mkFPLt(this, other)
    @JvmName("fpgt") public infix fun Expr<FPSort>.gt(other: Expr<FPSort>): BoolExpr = mkFPGt(this, other)
    @JvmName("fplte") public infix fun Expr<FPSort>.lte(other: Expr<FPSort>): BoolExpr = mkOr(mkFPEq(this, other), mkFPLt(this, other))
    @JvmName("fpgte") public infix fun Expr<FPSort>.gte(other: Expr<FPSort>): BoolExpr = mkOr(mkFPEq(this, other), mkFPGt(this, other))

    @JvmName("fpeq") public infix fun <S : FPSort> Expr<S>.eq(other: Int): BoolExpr = mkFPEq(this as Expr<FPSort>, mkFP(other, sort))
    @JvmName("fpneq") public infix fun <S : FPSort> Expr<S>.neq(other: Int): BoolExpr = mkNot(mkFPEq(this as Expr<FPSort>, mkFP(other, sort)))
    @JvmName("fplt") public infix fun <S : FPSort> Expr<S>.lt(other: Int): BoolExpr = mkFPLt(this as Expr<FPSort>, mkFP(other, sort))
    @JvmName("fpgt") public infix fun <S : FPSort> Expr<S>.gt(other: Int): BoolExpr = mkFPGt(this as Expr<FPSort>, mkFP(other, sort))
    @JvmName("fplte") public infix fun <S : FPSort> Expr<S>.lte(other: Int): BoolExpr = (this as Expr<FPSort>).lte(mkFP(other, sort))
    @JvmName("fpgte") public infix fun <S : FPSort> Expr<S>.gte(other: Int): BoolExpr = (this as Expr<FPSort>).gte(mkFP(other, sort))

    @JvmName("fpeq") public infix fun <S : FPSort> Expr<S>.eq(other: Float): BoolExpr = mkFPEq(this as Expr<FPSort>, mkFP(other, sort))
    @JvmName("fpneq") public infix fun <S : FPSort> Expr<S>.neq(other: Float): BoolExpr = mkNot(mkFPEq(this as Expr<FPSort>, mkFP(other, sort)))
    @JvmName("fplt") public infix fun <S : FPSort> Expr<S>.lt(other: Float): BoolExpr = mkFPLt(this as Expr<FPSort>, mkFP(other, sort))
    @JvmName("fpgt") public infix fun <S : FPSort> Expr<S>.gt(other: Float): BoolExpr = mkFPGt(this as Expr<FPSort>, mkFP(other, sort))
    @JvmName("fplte") public infix fun <S : FPSort> Expr<S>.lte(other: Float): BoolExpr = (this as Expr<FPSort>).lte(mkFP(other, sort))
    @JvmName("fpgte") public infix fun <S : FPSort> Expr<S>.gte(other: Float): BoolExpr = (this as Expr<FPSort>).gte(mkFP(other, sort))

    @JvmName("fpeq") public infix fun <S : FPSort> Expr<S>.eq(other: Double): BoolExpr = mkFPEq(this as Expr<FPSort>, mkFP(other, sort))
    @JvmName("fpneq") public infix fun <S : FPSort> Expr<S>.neq(other: Double): BoolExpr = mkNot(mkFPEq(this as Expr<FPSort>, mkFP(other, sort)))
    @JvmName("fplt") public infix fun <S : FPSort> Expr<S>.lt(other: Double): BoolExpr = mkFPLt(this as Expr<FPSort>, mkFP(other, sort))
    @JvmName("fpgt") public infix fun <S : FPSort> Expr<S>.gt(other: Double): BoolExpr = mkFPGt(this as Expr<FPSort>, mkFP(other, sort))
    @JvmName("fplte") public infix fun <S : FPSort> Expr<S>.lte(other: Double): BoolExpr = (this as Expr<FPSort>).lte(mkFP(other, sort))
    @JvmName("fpgte") public infix fun <S : FPSort> Expr<S>.gte(other: Double): BoolExpr = (this as Expr<FPSort>).gte(mkFP(other, sort))

    public infix fun BoolExpr.and(other: BoolExpr): BoolExpr = mkAnd(this, other)
    public infix fun BoolExpr.or(other: BoolExpr): BoolExpr = mkOr(this, other)
    public infix fun BoolExpr.xor(other: BoolExpr): BoolExpr = mkXor(this, other)
    public infix fun BoolExpr.implies(other: BoolExpr): BoolExpr = mkImplies(this, other)
    public infix fun BoolExpr.iff(other: BoolExpr): BoolExpr = mkIff(this, other)
    //endregion

    //region: Constructions
    public fun int(name: String): IntExpr = mkIntConst(name)
    public fun bitVec(name: String, size: Int): BitVecExpr = mkBVConst(name, size)
    //endregion

    //region: Conversions
    public fun Int.toZ3Int(): IntNum = mkInt(this)
    public fun Long.toZ3Int(): IntNum = mkInt(this)
    public fun Int.toBitVec(bits: Int): BitVecNum = mkBV(this, bits)
    public fun Long.toBitVec(bits: Int): BitVecNum = mkBV(this, bits)
    public fun IntExpr.toBitVec(bits: Int): BitVecExpr = mkInt2BV(bits, this)
    public fun BitVecExpr.toZ3Int(): IntExpr = mkBV2Int(this, false)
    public fun IntExpr.toReal(): RealExpr = mkInt2Real(this)
    public fun RealExpr.toZ3Int(): IntExpr = mkReal2Int(this)

    public fun Expr<*>.toInt(): Int = toString().toInt()
    public fun Expr<*>.toLong(): Long = toString().toLong()
    public fun Expr<*>.toDouble(): Double = toString().toDouble()
    public fun Expr<*>.toFloat(): Float = toString().toFloat()
    public fun Expr<*>.toBoolean(): Boolean = toString().toBoolean()
    //endregion

    //region: Operators
    public operator fun <T : ArithSort> Expr<T>.plus(other: Expr<T>): ArithExpr<T> = mkAdd(this, other)
    public operator fun <T : ArithSort> Expr<T>.minus(other: Expr<T>): ArithExpr<T> = mkSub(this, other)
    public operator fun <T : ArithSort> Expr<T>.times(other: Expr<T>): ArithExpr<T> = mkMul(this, other)
    public operator fun <T : ArithSort> Expr<T>.div(other: Expr<T>): ArithExpr<T> = mkDiv(this, other)

    public operator fun <T : ArithSort> Expr<T>.unaryMinus(): ArithExpr<T> = mkUnaryMinus(this)
    public operator fun Expr<IntSort>.rem(other: Expr<IntSort>): IntExpr = mkRem(this, other)

    public operator fun Expr<IntSort>.plus(other: Int): ArithExpr<IntSort> = this + mkInt(other)
    public operator fun Expr<IntSort>.minus(other: Int): ArithExpr<IntSort> = this - mkInt(other)
    public operator fun Expr<IntSort>.times(other: Int): ArithExpr<IntSort> = this * mkInt(other)
    public operator fun Expr<IntSort>.div(other: Int): ArithExpr<IntSort> = this / mkInt(other)
    public operator fun Expr<IntSort>.rem(other: Int): IntExpr = this % mkInt(other)

    public operator fun Expr<IntSort>.plus(other: Long): ArithExpr<IntSort> = this + mkInt(other)
    public operator fun Expr<IntSort>.minus(other: Long): ArithExpr<IntSort> = this - mkInt(other)
    public operator fun Expr<IntSort>.times(other: Long): ArithExpr<IntSort> = this * mkInt(other)
    public operator fun Expr<IntSort>.div(other: Long): ArithExpr<IntSort> = this / mkInt(other)
    public operator fun Expr<IntSort>.rem(other: Long): IntExpr = this % mkInt(other)

    public operator fun Int.plus(other: Expr<IntSort>): ArithExpr<IntSort> = mkInt(this) + other
    public operator fun Int.minus(other: Expr<IntSort>): ArithExpr<IntSort> = mkInt(this) - other
    public operator fun Int.times(other: Expr<IntSort>): ArithExpr<IntSort> = mkInt(this) * other
    public operator fun Int.div(other: Expr<IntSort>): ArithExpr<IntSort> = mkInt(this) / other
    public operator fun Int.rem(other: Expr<IntSort>): IntExpr = mkInt(this) % other

    public operator fun Long.plus(other: Expr<IntSort>): ArithExpr<IntSort> = mkInt(this) + other
    public operator fun Long.minus(other: Expr<IntSort>): ArithExpr<IntSort> = mkInt(this) - other
    public operator fun Long.times(other: Expr<IntSort>): ArithExpr<IntSort> = mkInt(this) * other
    public operator fun Long.div(other: Expr<IntSort>): ArithExpr<IntSort> = mkInt(this) / other
    public operator fun Long.rem(other: Expr<IntSort>): IntExpr = mkInt(this) % other

    public operator fun Expr<BitVecSort>.plus(other: Expr<BitVecSort>): BitVecExpr = mkBVAdd(this, other)
    public operator fun Expr<BitVecSort>.minus(other: Expr<BitVecSort>): BitVecExpr = mkBVSub(this, other)
    public operator fun Expr<BitVecSort>.times(other: Expr<BitVecSort>): BitVecExpr = mkBVMul(this, other)
    public operator fun Expr<BitVecSort>.div(other: Expr<BitVecSort>): BitVecExpr = mkBVSDiv(this, other)
    public operator fun Expr<BitVecSort>.rem(other: Expr<BitVecSort>): BitVecExpr = mkBVSRem(this, other)

    public operator fun Expr<BitVecSort>.unaryMinus(): BitVecExpr = mkBVNeg(this)

    public operator fun Expr<BitVecSort>.plus(other: Int): BitVecExpr = this + mkBV(other, sort.size)
    public operator fun Expr<BitVecSort>.minus(other: Int): BitVecExpr = this - mkBV(other, sort.size)
    public operator fun Expr<BitVecSort>.times(other: Int): BitVecExpr = this * mkBV(other, sort.size)
    public operator fun Expr<BitVecSort>.div(other: Int): BitVecExpr = this / mkBV(other, sort.size)
    public operator fun Expr<BitVecSort>.rem(other: Int): BitVecExpr = this % mkBV(other, sort.size)

    public operator fun Expr<BitVecSort>.plus(other: Long): BitVecExpr = this + mkBV(other, sort.size)
    public operator fun Expr<BitVecSort>.minus(other: Long): BitVecExpr = this - mkBV(other, sort.size)
    public operator fun Expr<BitVecSort>.times(other: Long): BitVecExpr = this * mkBV(other, sort.size)
    public operator fun Expr<BitVecSort>.div(other: Long): BitVecExpr = this / mkBV(other, sort.size)
    public operator fun Expr<BitVecSort>.rem(other: Long): BitVecExpr = this % mkBV(other, sort.size)

    public operator fun Int.plus(other: Expr<BitVecSort>): BitVecExpr = mkBV(this, other.sort.size) + other
    public operator fun Int.minus(other: Expr<BitVecSort>): BitVecExpr = mkBV(this, other.sort.size) - other
    public operator fun Int.times(other: Expr<BitVecSort>): BitVecExpr = mkBV(this, other.sort.size) * other
    public operator fun Int.div(other: Expr<BitVecSort>): BitVecExpr = mkBV(this, other.sort.size) / other
    public operator fun Int.rem(other: Expr<BitVecSort>): BitVecExpr = mkBV(this, other.sort.size) % other

    public operator fun Long.plus(other: Expr<BitVecSort>): BitVecExpr = mkBV(this, other.sort.size) + other
    public operator fun Long.minus(other: Expr<BitVecSort>): BitVecExpr = mkBV(this, other.sort.size) - other
    public operator fun Long.times(other: Expr<BitVecSort>): BitVecExpr = mkBV(this, other.sort.size) * other
    public operator fun Long.div(other: Expr<BitVecSort>): BitVecExpr = mkBV(this, other.sort.size) / other
    public operator fun Long.rem(other: Expr<BitVecSort>): BitVecExpr = mkBV(this, other.sort.size) % other

    @JvmName("plusReal") public operator fun Expr<RealSort>.plus(other: Int): ArithExpr<RealSort> = this + mkReal(other)
    @JvmName("minusReal") public operator fun Expr<RealSort>.minus(other: Int): ArithExpr<RealSort> = this - mkReal(other)
    @JvmName("timesReal") public operator fun Expr<RealSort>.times(other: Int): ArithExpr<RealSort> = this * mkReal(other)
    @JvmName("divReal") public operator fun Expr<RealSort>.div(other: Int): ArithExpr<RealSort> = this / mkReal(other)

    @JvmName("plusReal") public operator fun Expr<RealSort>.plus(other: Long): ArithExpr<RealSort> = this + mkReal(other)
    @JvmName("minusReal") public operator fun Expr<RealSort>.minus(other: Long): ArithExpr<RealSort> = this - mkReal(other)
    @JvmName("timesReal") public operator fun Expr<RealSort>.times(other: Long): ArithExpr<RealSort> = this * mkReal(other)
    @JvmName("divReal") public operator fun Expr<RealSort>.div(other: Long): ArithExpr<RealSort> = this / mkReal(other)

    @JvmName("plusReal") public operator fun Int.plus(other: Expr<RealSort>): ArithExpr<RealSort> = mkReal(this) + other
    @JvmName("minusReal") public operator fun Int.minus(other: Expr<RealSort>): ArithExpr<RealSort> = mkReal(this) - other
    @JvmName("timesReal") public operator fun Int.times(other: Expr<RealSort>): ArithExpr<RealSort> = mkReal(this) * other
    @JvmName("divReal") public operator fun Int.div(other: Expr<RealSort>): ArithExpr<RealSort> = mkReal(this) / other

    @JvmName("plusReal") public operator fun Long.plus(other: Expr<RealSort>): ArithExpr<RealSort> = mkReal(this) + other
    @JvmName("minusReal") public operator fun Long.minus(other: Expr<RealSort>): ArithExpr<RealSort> = mkReal(this) - other
    @JvmName("timesReal") public operator fun Long.times(other: Expr<RealSort>): ArithExpr<RealSort> = mkReal(this) * other
    @JvmName("divReal") public operator fun Long.div(other: Expr<RealSort>): ArithExpr<RealSort> = mkReal(this) / other

    public operator fun BoolExpr.not(): BoolExpr = mkNot(this)
    //endregion

    //region: Non-operator-fun math operations
    public infix fun Expr<IntSort>.mod(other: Expr<IntSort>): IntExpr = mkMod(this, other)
    public infix fun Expr<IntSort>.mod(other: Int): IntExpr = mkMod(this, mkInt(other))
    public infix fun Expr<IntSort>.mod(other: Long): IntExpr = mkMod(this, mkInt(other))
    public infix fun Int.mod(other: Expr<IntSort>): IntExpr = mkMod(mkInt(this), other)
    public infix fun Long.mod(other: Expr<IntSort>): IntExpr = mkMod(mkInt(this), other)

    public infix fun <T : ArithSort> Expr<T>.pow(other: Expr<T>): ArithExpr<T> = mkPower(this, other)
    public infix fun Expr<IntSort>.pow(other: Int): ArithExpr<IntSort> = mkPower(this, mkInt(other))
    public infix fun Expr<IntSort>.pow(other: Long): ArithExpr<IntSort> = mkPower(this, mkInt(other))
    public infix fun Int.pow(other: Expr<IntSort>): ArithExpr<IntSort> = mkPower(mkInt(this), other)
    public infix fun Long.pow(other: Expr<IntSort>): ArithExpr<IntSort> = mkPower(mkInt(this), other)

    public infix fun Expr<BitVecSort>.mod(other: Expr<BitVecSort>): BitVecExpr = mkBVSMod(this, other)
    public infix fun Expr<BitVecSort>.mod(other: Int): BitVecExpr = mkBVSMod(this, mkBV(other, sort.size))
    public infix fun Expr<BitVecSort>.mod(other: Long): BitVecExpr = mkBVSMod(this, mkBV(other, sort.size))
    public infix fun Int.mod(other: Expr<BitVecSort>): BitVecExpr = mkBVSMod(mkBV(this, other.sort.size), other)
    public infix fun Long.mod(other: Expr<BitVecSort>): BitVecExpr = mkBVSMod(mkBV(this, other.sort.size), other)
    //endregion

    //region: Extra
    public class IfThen<T : Sort> internal constructor(internal val condition: BoolExpr, internal val then: Expr<T>)
    public infix fun <T : Sort> BoolExpr.ifTrue(then: Expr<T>): IfThen<T> = IfThen(this, then)
    public infix fun <T : Sort> IfThen<T>.ifFalse(otherwise: Expr<T>): Expr<T> = mkITE(condition, then, otherwise)
    @JvmName("ternaryIf") public infix fun <T : Sort> BoolExpr.`?`(then: Expr<T>): IfThen<T> = ifTrue(then)
    @JvmName("ternaryElse") @Suppress("INVALID_CHARACTERS") public infix fun <T : Sort> IfThen<T>.`:`(otherwise: Expr<T>): Expr<T> = ifFalse(otherwise)
    public fun Expr<IntSort>.abs(): Expr<IntSort> = mkITE(this gte 0, this, -this)
    public fun Expr<IntSort>.sign(): Expr<IntSort> = mkITE(this eq 0, 0.toZ3Int(), mkITE(this gte 0, 1.toZ3Int(), (-1).toZ3Int()))
    @JvmName("absReal") public fun Expr<RealSort>.abs(): Expr<RealSort> = mkITE(this gte 0, this, this * mkReal(-1))
    @JvmName("signReal") public fun Expr<RealSort>.sign(): Expr<RealSort> = mkITE(this eq 0, mkReal(0), mkITE(this gte 0, mkReal(1), mkReal(-1)))
    @JvmName("absBV") public fun Expr<BitVecSort>.abs(): Expr<BitVecSort> = mkITE(this gte 0, this, -this)
    @JvmName("signBV") public fun Expr<BitVecSort>.sign(): Expr<BitVecSort> = mkITE(this eq 0, 0.toBitVec(sort.size), mkITE(this gte 0, 1.toBitVec(sort.size), (-1).toBitVec(sort.size)))

    public inline val Expr<IntSort>.absoluteValue: Expr<IntSort> get() = abs()
    public inline val Expr<IntSort>.sign: Expr<IntSort> get() = sign()
    public inline val Expr<RealSort>.absoluteValue: Expr<RealSort> @JvmName("get_absReal") get() = abs()
    public inline val Expr<RealSort>.sign: Expr<RealSort> @JvmName("get_signReal") get() = sign()
    public inline val Expr<BitVecSort>.absoluteValue: Expr<BitVecSort> @JvmName("get_absBV") get() = abs()
    public inline val Expr<BitVecSort>.sign: Expr<BitVecSort> @JvmName("get_signBV") get() = sign()
    //endregion
}
