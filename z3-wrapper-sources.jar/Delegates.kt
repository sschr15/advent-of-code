package com.sschr15.z3kt

import com.microsoft.z3.BitVecExpr
import com.microsoft.z3.BoolExpr
import com.microsoft.z3.Expr
import com.microsoft.z3.IntExpr
import com.microsoft.z3.RealExpr
import kotlin.properties.PropertyDelegateProvider
import kotlin.properties.ReadOnlyProperty
import kotlin.reflect.KProperty

public class ExprDelegateProvider<T : Expr<*>> internal constructor(
    private val context: Z3Context,
    private val getter: Z3Context.(String) -> T
) : PropertyDelegateProvider<Any?, ExprDelegateProvider.Delegate<T>> {
    public class Delegate<T : Expr<*>>(private val value: T) : ReadOnlyProperty<Any?, T> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): T = value
    }

    override fun provideDelegate(thisRef: Any?, property: KProperty<*>): Delegate<T> {
        val name = property.name
        return Delegate(context.getter(name))
    }
}

public val Z3Context.bool: ExprDelegateProvider<BoolExpr>
    get() = ExprDelegateProvider(this) { mkBoolConst(it) }

public val Z3Context.int: ExprDelegateProvider<IntExpr>
    get() = ExprDelegateProvider(this) { mkIntConst(it) }

public val Z3Context.real: ExprDelegateProvider<RealExpr>
    get() = ExprDelegateProvider(this) { mkRealConst(it) }

public fun Z3Context.bitVec(size: Int): ExprDelegateProvider<BitVecExpr>
    = ExprDelegateProvider(this) { mkBVConst(it, size) }
